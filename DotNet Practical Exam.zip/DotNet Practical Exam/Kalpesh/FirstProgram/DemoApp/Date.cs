public class Date
{
    public int Day{ get; set;}
    public int Month{ get; set;}
    public int Year{ get; set;}

    //parameterized constructor
    public Date(int Day,int Month,int Year)
    {
        this.Day=Day;
        this.Month=Month;
        this.Year=Year;

    }

}