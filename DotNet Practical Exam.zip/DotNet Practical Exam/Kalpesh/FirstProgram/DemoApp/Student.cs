public class Student  // public class
{
    // get and set property
    public int Id{ get; set;} 
    public string Name{ get; set;}
    public Date dateOfBirth{ get; set;}
    public int[] marks = new int[3];
    
    //parameterized constructor
    public Student(int Id,string Name,Date date,int []marks)
    {
        this.Id = Id;
        this.Name = Name;
        this.dateOfBirth = date;
        this.marks = marks;

    }
}