﻿int[] marks=new int[]{85,90,75};
Date date=new Date(16,02,1997);
Student std = new Student(1,"Kalpesh",date,marks);
Console.WriteLine("Details Of Student");
Console.WriteLine("Id,Name and DateofBirth:{0,6}{1,12}\t{2}/{3}/{4}",std.Id,std.Name,std.dateOfBirth.Day,std.dateOfBirth.Month,std.dateOfBirth.Year);

Console.WriteLine($"Marks of Three Subjects : {std.marks[0]}\t{std.marks[1]}\t{std.marks[2]}");

