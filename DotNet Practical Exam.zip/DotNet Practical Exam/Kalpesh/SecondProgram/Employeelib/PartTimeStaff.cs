namespace EmployeeLib;

public class PartTimeStaff : Staff
{
    //private string Department;
    //public double Salary;

    public int Hours { get; set; }

    public double RatePerHour { get; set;}

    public PartTimeStaff(string Name, string Address, int Hours,double RatePerHour) : base(Name,Address)
    {
        this.Hours = Hours;
        this.RatePerHour = RatePerHour; 
    }

    public PartTimeStaff() : this("JITU","Mumbai",180,500)
    {    
    }

    public void Display()
    {
        Console.WriteLine($"Employee:{Name}  Lives At:{Address}  Working for {Hours}  Earns Rs{RatePerHour}per hour");
    }
}