﻿namespace EmployeeLib;
public abstract class Staff
{
    //private string Name;
    //private string Address;

    public string Name { set; get;}

    public string Address { set; get;}


    public Staff(string Name,string Address)
    {
        this.Name = Name;
        this.Address = Address;
    }

    public Staff() : this("Ram", "Mumbai")
    { 
    }
}
