namespace EmployeeLib;

public class FullTimeStaff : Staff
{
    //private string Department;
    //public double Salary;

    public string Department { get; set; }

    public double Salary { get; set;}

    public FullTimeStaff(string Name, string Address, string Department,double Salary) : base(Name,Address)
    {
        this.Department = Department;
        this.Salary = Salary; 
    }

    public FullTimeStaff() : this("Ram","Mumbai","Management",60000)
    {    
    }

    public void Display()
    {
        Console.WriteLine($"Employee:{Name} Lives At:{Address} Working in {Department} Earns Rs{Salary}");
    }
}