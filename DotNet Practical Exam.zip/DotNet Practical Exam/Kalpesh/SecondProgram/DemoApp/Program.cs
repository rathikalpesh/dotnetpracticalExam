﻿using EmployeeLib;
Console.WriteLine("Enter 1 for Full Time Staff \n Enter 2 for Part Time Staff");

int n = int.Parse(Console.ReadLine());

switch(n)
{
    case 1:
        ICollection<FullTimeStaff> staff = AllStaff.GetFullStaff();
        foreach(var entry in staff)
            entry.Display();
            break;

    case 2:
        ICollection<PartTimeStaff> pstaff = AllStaff.GetPartStaff();
        foreach(var entry in pstaff)
            entry.Display();
            break;
       
}

class AllStaff
{

    //NOTE: Change The Values for both the lists 
public static ICollection<FullTimeStaff> GetFullStaff()
{
    var staff = new List<FullTimeStaff>();
    staff.Add(new FullTimeStaff("Subodh","Pune","Account",60000));
    staff.Add(new FullTimeStaff("Shreyash","Nagpur","Management",50000));
    staff.Add(new FullTimeStaff("Nitin","Mumbai","Mentainance",60000));    
    staff.Add(new FullTimeStaff("Kalpesh","Amravati","HR",100000));
    
    return staff;
}
public static ICollection<PartTimeStaff> GetPartStaff()
{
    var staff = new List<PartTimeStaff>();
    staff.Add(new PartTimeStaff("Akanksha","Amravti",180,500));
    staff.Add(new PartTimeStaff("Nikhil","Pune",140,500));
    staff.Add(new PartTimeStaff("Manish","Pune",160,500));
    staff.Add(new PartTimeStaff("Sham","Pune",120,500));
    return staff;
}

}